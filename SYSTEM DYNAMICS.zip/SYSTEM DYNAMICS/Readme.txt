VensimPLE

This directory contains all the necessary information for installing the VensimPLE software. 
Directory contains three sub-directoris:
VensimPLE
Tutorial
Examples

VensimPLE sub-directory contains the program installation files. Select venple32.exe and follow 
instructions on the screen to install th eprogram on your computer.  VensimPLE (Personal Learning 
Edition) is available from the Ventana Systems Inc. web site http://www.vensim.com  (last accessed 
in December of 2005). 

Tutorial sub-directory contains a short tutorial for Vensim PLE developed by Professor Craig Kirkwood 
at Arizona State University. Use of the tutorial is permitted by the author.

Examples sub-directory contains all the examples from Section 8 of the textbook. 


S.P. Simonovic									October 1, 2007. 