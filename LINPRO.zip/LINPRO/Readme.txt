Linpro

This directory contains all the necessary information for installing the Linpro software. 
Directory contains two sub-directories:
Linpro
Examples.

Linpro sub-directory contains the program installation files. Linpro requires the .NET 
Framework 2.0 to be installed on the target machine. If the target machine does not have .NET Framework 
installed, double click on the file named dotnetfx.exe. After the installation of .NET Framework proceed with the 
installation of the Linpro software by running Setup.exe � follow instructions on the screen.

Examples sub-directory contains all the examples from Section 9.3 of the textbook. 


S.P. Simonovic									October 2007. 

