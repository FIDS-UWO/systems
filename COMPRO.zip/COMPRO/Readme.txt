Compro 

This directory contains all the necessary information for installing the Compro software. 
Directory contains two sub-directories:
Compro
Examples.

Compro sub-directory contains the program installation files. Compro requires the .NET Framework 2.0 
installed on the target machine. If the target machine does not have .NET Framework installed, 
double click on the file named dotnetfx.exe.After the installation of .NET Framework proceed with the 
installation of the Compro software by running Setup.exe � follow instructions on the screen.

Examples sub-directory contains all the examples from Section 10.3 of the textbook. 


S.P. Simonovic									October 2007. 

