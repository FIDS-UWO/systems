FuzzyCompro 

This directory contains all the necessary information for installing the FuzzyCompro software. 
Directory contains two sub-directories:
FuzzyCompro
Examples.

FuzzyCompro sub-directory contains the program installation files. FuzzyCompro requires the .NET Framework 2.0 
to be installed on the target machine. If the target machine does not have .NET Framework installed, 
double click on the file named dotnetfx.exe. After the installation of .NET Framework proceed with the 
installation of the FuzzyCompro software by running Setup.exe � follow instructions on the screen.

Examples sub-directory contains all the examples from Section 10.4 of the textbook. 


S.P. Simonovic									October 2007. 

